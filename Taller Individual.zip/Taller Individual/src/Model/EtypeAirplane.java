package Model;

public enum EtypeAirplane {

}
