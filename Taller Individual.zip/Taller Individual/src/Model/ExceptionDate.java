package Model;

import java.util.Arrays;

public class ExceptionDate extends Exception {

	


}
